<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Symfony\Component\Intl\Countries;

class TrafficReportController extends Controller
{
    /* ---------------- ownership & scoping ---------------- */

    /**
     * Return all traffic sites this user is allowed to see:
     *  - in the user’s workspace (traffic_sites.workspace_id = user->workspace_id)
     */
    private function trafficSitesForUser(Request $request)
    {
        $user = $request->user();
        $workspaceId = (int) ($user->workspace_id ?? 0);

        if ($workspaceId <= 0) {
            Log::debug('No valid workspace_id for user ID ' . ($user->id ?? 'unknown') . ', value: ' . ($user->workspace_id ?? 'null'));
            return collect();
        }

        $sites = DB::table('traffic_sites')
            ->select('id', 'origin_host', 'workspace_id')
            ->where('workspace_id', $workspaceId)
            ->orderBy('origin_host')
            ->get();

        Log::debug('Query for workspace_id ' . $workspaceId . ' returned ' . $sites->count() . ' sites. Raw data: ' . json_encode($sites->toArray()));
        return $sites;
    }

    /**
     * Pick a site id that belongs to the user from the provided hosts list.
     * If the requested id is not allowed, it’s ignored.
     * Returns int site id or null if no sites exist.
     */
    private function pickSiteId(Request $request, $hosts): ?int
    {
        if (!$hosts || $hosts->isEmpty()) {
            Log::debug('No hosts available for site selection');
            return null;
        }

        $requested = (int) $request->input('traffic_site_id', 0);
        Log::debug('Requested traffic_site_id: ' . $requested . ', Hosts: ' . json_encode($hosts->pluck('id')->toArray()));
        if ($requested && $hosts->firstWhere('id', $requested)) {
            Log::debug('Using requested site ID: ' . $requested);
            return $requested;
        }
        // Default to first allowed site
        $firstId = (int) $hosts->first()->id;
        Log::debug('Defaulting to first site ID: ' . $firstId);
        return $firstId;
    }

    /* ---------------- existing helpers you already had ---------------- */

    private function sanitizeRange(?string $range): string
    {
        return in_array($range, ['7d', '30d'], true) ? $range : '7d';
    }

    private function rangeToDates(string $range): array
    {
        $end = Carbon::now('UTC')->minute(0)->second(0);
        $start = $range === '30d' ? $end->copy()->subDays(30) : $end->copy()->subDays(7);
        return [$start, $end];
    }

    /* ---------------- pages ---------------- */

    public function overview(Request $request)
    {
        $range = $this->sanitizeRange($request->input('range'));
        [$start, $end] = $this->rangeToDates($range);

        // ⚠️ Ownership scope
        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        // If user has no sites, render with Not connected card
        if (!$trafficSiteId) {
            $user = $request->user();
            Log::debug('No traffic site ID for user ID ' . ($user->id ?? 'unknown') . ' with workspace_id ' . ($user->workspace_id ?? 'null') . '. Hosts: ' . json_encode($hosts->toArray()));
            return view('traffic.container', [
                'view'            => 'index',
                'hosts'           => $hosts,
                'currentHost'     => null,
                'traffic_site_id' => null,
                'series'          => collect(),
                'topPages'        => collect(),
                'referrers'       => collect(),
                'countries'       => collect(),
                'browsers'        => collect(),
                'oss'             => collect(),
                'range'           => $range,
                'kpi'             => [
                    'windowDays' => ($range === '30d' ? 30 : 7),
                    'visitors'   => ['value' => 0, 'delta' => null],
                    'pageviews'  => ['value' => 0, 'delta' => null],
                    'engagement' => ['value' => 0, 'delta' => null],
                    'online'     => ['value' => 0],
                ],
            ]);
        }

        // ---- Your existing data queries (unchanged) ----
        $series = DB::table('traffic_hourly')
            ->select(
                'hour',
                DB::raw('SUM(pageviews) as pv'),
                DB::raw('SUM(sessions)  as ss'),
                DB::raw('SUM(engaged)   as eg')
            )
            ->where('site_id', $trafficSiteId)
            ->whereBetween('hour', [$start, $end])
            ->groupBy('hour')
            ->orderBy('hour')
            ->get();

        $topPages = DB::table('traffic_hourly')
            ->selectRaw("
                SUBSTRING_INDEX(url, '?', 1) AS url_noq,
                MAX(post_id) AS post_id,
                SUM(pageviews) AS pv,
                SUM(sessions)  AS ss,
                SUM(engaged)   AS eg
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('hour', [$start, $end])
            ->whereNotNull('url')->where('url', '!=', '')
            ->groupBy('url_noq')
            ->orderByDesc('pv')
            ->limit(20)
            ->get();

        // Side lists (referrers, countries, browsers, os) – keep your existing versions
        $referrers = DB::table('traffic_events_raw')
            ->selectRaw("
                LOWER(TRIM(LEADING 'www.' FROM SUBSTRING_INDEX(SUBSTRING_INDEX(referrer, '/', 3), '//', -1))) AS name,
                SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('ts', [$start, $end])
            ->whereNotNull('referrer')->where('referrer', '!=', '')
            ->groupBy('name')->orderByDesc('pv')->limit(8)->get();

        $countries = DB::table('traffic_events_raw')
            ->selectRaw("
                UPPER(NULLIF(country, '')) AS name,
                COUNT(*) AS pv
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('ts', [$start, $end])
            ->where('event_type', 'page_view')
            ->groupBy('name')->orderByDesc('pv')->limit(8)->get();

        $browsers = DB::table('traffic_events_raw')
            ->selectRaw("
                COALESCE(NULLIF(ua_browser, ''), 'Unknown') AS name,
                SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('ts', [$start, $end])
            ->groupBy('name')->orderByDesc('pv')->limit(8)->get();

        $oss = DB::table('traffic_events_raw')
            ->selectRaw("
                COALESCE(NULLIF(ua_os, ''), 'Unknown') AS name,
                SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('ts', [$start, $end])
            ->groupBy('name')->orderByDesc('pv')->limit(8)->get();

        // KPI block (simple version; keep your richer version if you want)
        $tot = DB::table('traffic_events_raw')
            ->selectRaw("
                SUM(CASE WHEN event_type='page_view'   THEN 1 ELSE 0 END) AS pv,
                SUM(CASE WHEN event_type='scroll_depth' THEN 1 ELSE 0 END) AS eg
            ")
            ->where('site_id', $trafficSiteId)
            ->whereBetween('ts', [$start, $end])
            ->first();
        $liveNow = (int) DB::table('traffic_events_raw')
            ->where('site_id', $trafficSiteId)
            ->where('event_type', 'page_view')
            ->whereBetween('ts', [$end->copy()->subMinutes(5), $end])
            ->distinct('anon_id')->count('anon_id');

        $kpi = [
            'windowDays' => ($range === '30d' ? 30 : 7),
            'visitors'   => ['value' => 0, 'delta' => null], // you can compute distinct anon_id if you like
            'pageviews'  => ['value' => (int) ($tot->pv ?? 0), 'delta' => null],
            'engagement' => ['value' => (int) ($tot->eg ?? 0), 'delta' => null],
            'online'     => ['value' => $liveNow],
        ];

        return view('traffic.container', [
            'view'            => 'index',
            'hosts'           => $hosts,
            'currentHost'     => $currentHost,
            'traffic_site_id' => $trafficSiteId,
            'series'          => $series,
            'topPages'        => $topPages,
            'referrers'       => $referrers,
            'countries'       => $countries,
            'browsers'        => $browsers,
            'oss'             => $oss,
            'range'           => $range,
            'kpi'             => $kpi,
        ]);
    }

    public function health(Request $request)
    {
        // ⚠️ Ownership scope
        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        if (!$trafficSiteId) {
            Log::debug('No traffic site ID for health check. Hosts: ' . json_encode($hosts->toArray()));
            return response()->json(['status' => 'no-site', 'online' => 0]);
        }

        $now = Carbon::now('UTC');
        $online = (int) DB::table('traffic_events_raw')
            ->where('site_id', $trafficSiteId)
            ->where('event_type', 'page_view')
            ->whereBetween('ts', [$now->copy()->subMinutes(5), $now])
            ->distinct('anon_id')->count('anon_id');

        return response()->json(['status' => 'ok', 'online' => $online]);
    }

    public function show(Request $request, $postId = null)
    {
        $range = $this->sanitizeRange($request->input('range', '7d'));
        [$start, $end] = $this->rangeToDates($range);

        // ⚠️ Ownership scope
        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        if ($request->get('view') === 'top') {
            if (!$trafficSiteId) {
                Log::debug('No traffic site ID for top view. Hosts: ' . json_encode($hosts->toArray()));
                return view('traffic.container', [
                    'view'            => 'show',
                    'hosts'           => $hosts,
                    'currentHost'     => null,
                    'traffic_site_id' => null,
                    'topPages'        => collect(),
                    'range'           => $range,
                ]);
            }

            $topPages = DB::table('traffic_hourly')
                ->selectRaw("
                    SUBSTRING_INDEX(url, '?', 1) AS url_noq,
                    MAX(post_id) AS post_id,
                    SUM(pageviews) AS pv,
                    SUM(sessions)  AS ss,
                    SUM(engaged)   AS eg
                ")
                ->where('site_id', $trafficSiteId)
                ->whereBetween('hour', [$start, $end])
                ->whereNotNull('url')->where('url', '!=', '')
                ->groupBy('url_noq')
                ->orderByDesc('pv')
                ->paginate(50);

            return view('traffic.container', [
                'view'            => 'show',
                'hosts'           => $hosts,
                'currentHost'     => $currentHost,
                'traffic_site_id' => $trafficSiteId,
                'topPages'        => $topPages,
                'range'           => $range,
            ]);
        }

        // if you support per-post charts, keep your existing logic here,
        // but always use $trafficSiteId (never trust the raw request id)

        abort(404);
    }

    public function referrers(Request $request)
    {
        $range = $this->sanitizeRange($request->input('range'));
        [$start, $end] = $this->rangeToDates($range);

        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        $rows = $trafficSiteId
            ? DB::table('traffic_events_raw')
                ->selectRaw("
                    LOWER(TRIM(LEADING 'www.' FROM SUBSTRING_INDEX(SUBSTRING_INDEX(referrer, '/', 3), '//', -1))) AS name,
                    SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv
                ")
                ->where('site_id', $trafficSiteId)
                ->whereBetween('ts', [$start, $end])
                ->whereNotNull('referrer')->where('referrer', '!=', '')
                ->groupBy('name')->orderByDesc('pv')->limit(200)->get()
            : collect();

        return view('traffic.container', [
            'view' => 'list',
            'title' => __('Referrers'),
            'hosts' => $hosts,
            'currentHost' => $currentHost,
            'traffic_site_id' => $trafficSiteId,
            'range' => $range,
            'rows' => $rows,
            'nameKey' => 'name',
            'valueKey' => 'pv',
            'nameLabel' => __('Website'),
            'valueLabel' => __('Pageviews'),
        ]);
    }

    public function countries(Request $request)
    {
        $range = $this->sanitizeRange($request->input('range'));
        [$start, $end] = $this->rangeToDates($range);

        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        $rows = $trafficSiteId
            ? DB::table('traffic_events_raw')
                ->selectRaw("UPPER(NULLIF(country, '')) AS name, COUNT(*) AS pv")
                ->where('site_id', $trafficSiteId)
                ->whereBetween('ts', [$start, $end])
                ->where('event_type', 'page_view')
                ->groupBy('name')->orderByDesc('pv')->limit(200)->get()
            : collect();

        return view('traffic.container', [
            'view' => 'list',
            'title' => __('Countries'),
            'hosts' => $hosts,
            'currentHost' => $currentHost,
            'traffic_site_id' => $trafficSiteId,
            'range' => $range,
            'rows' => $rows,
            'nameKey' => 'name',
            'valueKey' => 'pv',
            'nameLabel' => __('Name'),
            'valueLabel' => __('Pageviews'),
        ]);
    }

    public function browsers(Request $request)
    {
        $range = $this->sanitizeRange($request->input('range'));
        [$start, $end] = $this->rangeToDates($range);

        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        $rows = $trafficSiteId
            ? DB::table('traffic_events_raw')
                ->selectRaw("COALESCE(NULLIF(ua_browser, ''), 'Unknown') AS name, SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv")
                ->where('site_id', $trafficSiteId)
                ->whereBetween('ts', [$start, $end])
                ->groupBy('name')->orderByDesc('pv')->limit(200)->get()
            : collect();

        return view('traffic.container', [
            'view' => 'list',
            'title' => __('Browsers'),
            'hosts' => $hosts,
            'currentHost' => $currentHost,
            'traffic_site_id' => $trafficSiteId,
            'range' => $range,
            'rows' => $rows,
            'nameKey' => 'name',
            'valueKey' => 'pv',
            'nameLabel' => __('Name'),
            'valueLabel' => __('Pageviews'),
        ]);
    }

    public function os(Request $request)
    {
        $range = $this->sanitizeRange($request->input('range'));
        [$start, $end] = $this->rangeToDates($range);

        $hosts = $this->trafficSitesForUser($request);
        $trafficSiteId = $this->pickSiteId($request, $hosts);
        $currentHost = $trafficSiteId ? $hosts->firstWhere('id', $trafficSiteId) : null;

        $rows = $trafficSiteId
            ? DB::table('traffic_events_raw')
                ->selectRaw("COALESCE(NULLIF(ua_os, ''), 'Unknown') AS name, SUM(CASE WHEN event_type='page_view' THEN 1 ELSE 0 END) AS pv")
                ->where('site_id', $trafficSiteId)
                ->whereBetween('ts', [$start, $end])
                ->groupBy('name')->orderByDesc('pv')->limit(200)->get()
            : collect();

        return view('traffic.container', [
            'view' => 'list',
            'title' => __('Operating Systems'),
            'hosts' => $hosts,
            'currentHost' => $currentHost,
            'traffic_site_id' => $trafficSiteId,
            'range' => $range,
            'rows' => $rows,
            'nameKey' => 'name',
            'valueKey' => 'pv',
            'nameLabel' => __('Name'),
            'valueLabel' => __('Pageviews'),
        ]);
    }
}