@section('site_title', formatTitle([__('Traffic'), config('settings.title')]))

{{-- Breadcrumbs (match Links page) --}}
@include('shared.breadcrumbs', ['breadcrumbs' => [
    ['url' => route('dashboard'), 'title' => __('Home')],
    ['title' => __('Traffic')],
]])

{{-- Page header (match Links page header row) --}}
<div class="d-flex">
    <div class="flex-grow-1">
        <h1 class="h2 mb-0 d-inline-block">{{ __('Traffic') }}</h1>
    </div>
    <div class="col-auto pl-0">
        <form method="get" class="d-inline-block">
            <select name="range" class="custom-select custom-select-sm" onchange="this.form.submit()">
                <option value="7d" {{ $range==='7d' ? 'selected' : '' }}>{{ __('Last 7 days') }}</option>
                <option value="30d" {{ $range==='30d' ? 'selected' : '' }}>{{ __('Last 30 days') }}</option>
            </select>
        </form>
    </div>
</div>

{{-- Site overview card --}}
<div class="card border-0 shadow-sm mt-3">
    <div class="card-header">
        <div class="font-weight-medium py-1">{{ __('Site Overview') }}</div>
    </div>
    <div class="card-body">
        <canvas id="trafficChart" height="80"></canvas>
    </div>
</div>

{{-- Top posts card --}}
<div class="card border-0 shadow-sm mt-3">
    <div class="card-header">
        <div class="font-weight-medium py-1">{{ __('Top Posts') }}</div>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead>
                    <tr class="text-muted small">
                        <th class="border-0">{{ __('Post ID') }}</th>
                        <th class="border-0">{{ __('Pageviews') }}</th>
                        <th class="border-0">{{ __('Sessions') }}</th>
                        <th class="border-0">{{ __('Engaged') }}</th>
                        <th class="border-0 text-right"></th>
                    </tr>
                </thead>
                <tbody>
                @forelse($topPosts as $row)
                    <tr>
                        <td>{{ $row->post_id ?? '—' }}</td>
                        <td>{{ number_format($row->pv) }}</td>
                        <td>{{ number_format($row->ss) }}</td>
                        <td>{{ number_format($row->eg) }}</td>
                        <td class="text-right">
                            @if($row->post_id)
                                <a class="btn btn-sm btn-outline-primary"
                                   href="{{ route('traffic.show', ['postId' => $row->post_id, 'range' => $range]) }}">
                                    {{ __('View') }}
                                </a>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-center text-muted py-4">{{ __('No data yet.') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function(){
  const series = @json($series);
  const labels = series.map(p => p.hour);
  const pv = series.map(p => p.pv);
  const ss = series.map(p => p.ss);
  const eg = series.map(p => p.eg);
  const ctx = document.getElementById('trafficChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [
      { label:'{{ __("Pageviews") }}', data: pv, fill:false },
      { label:'{{ __("Sessions") }}',  data: ss, fill:false },
      { label:'{{ __("Engaged") }}',   data: eg, fill:false }
    ]},
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      scales: { y: { beginAtZero: true } }
    }
  });
})();
</script>
@endpush
