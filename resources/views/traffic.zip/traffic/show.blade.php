@section('site_title', formatTitle([__('Traffic'), __('Post') . ' ' . $postId, config('settings.title')]))

{{-- Breadcrumbs (match Links page style) --}}
@include('shared.breadcrumbs', ['breadcrumbs' => [
    ['url' => route('dashboard'), 'title' => __('Home')],
    ['url' => route('traffic.index'), 'title' => __('Traffic')],
    ['title' => __('Post') . ' #' . $postId],
]])

{{-- Page header --}}
<div class="d-flex">
    <div class="flex-grow-1">
        <h1 class="h2 mb-0 d-inline-block">{{ __('Post Traffic') }} — #{{ $postId }}</h1>
    </div>
    <div class="col-auto pl-0">
        <form method="get" class="d-inline-block">
            <input type="hidden" name="postId" value="{{ $postId }}">
            <select name="range" class="custom-select custom-select-sm" onchange="this.form.submit()">
                <option value="7d"  {{ $range==='7d'  ? 'selected' : '' }}>{{ __('Last 7 days') }}</option>
                <option value="30d" {{ $range==='30d' ? 'selected' : '' }}>{{ __('Last 30 days') }}</option>
            </select>
        </form>
    </div>
</div>

<div class="row mt-3">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header">
                <div class="font-weight-medium py-1">{{ __('Timeseries') }}</div>
            </div>
            <div class="card-body">
                <canvas id="postChart" height="110"></canvas>
            </div>
        </div>
    </div>

    <div class="col-lg-4 mt-3 mt-lg-0">
        <div class="card border-0 shadow-sm">
            <div class="card-header">
                <div class="font-weight-medium py-1">{{ __('Top Referrers') }}</div>
            </div>
            <div class="card-body">
                @if(count($refs))
                    <ul class="list-unstyled mb-0">
                        @foreach($refs as $r)
                            <li class="d-flex justify-content-between py-1">
                                <span class="text-truncate pr-3">{{ $r->referrer_host }}</span>
                                <span class="font-weight-medium">{{ number_format($r->pv) }}</span>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <div class="text-muted">{{ __('No data yet.') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function(){
  const series = @json($series);
  const labels = series.map(p => p.hour);
  const pv = series.map(p => p.pv);
  const ss = series.map(p => p.ss);
  const eg = series.map(p => p.eg);
  const ctx = document.getElementById('postChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [
      { label:'{{ __("Pageviews") }}', data: pv, fill:false },
      { label:'{{ __("Sessions") }}',  data: ss, fill:false },
      { label:'{{ __("Engaged") }}',   data: eg, fill:false }
    ]},
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      scales: { y: { beginAtZero: true } }
    }
  });
})();
</script>
@endpush
